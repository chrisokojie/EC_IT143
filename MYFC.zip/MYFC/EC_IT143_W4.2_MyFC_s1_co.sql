/*
    Ensign College � IT 143
    Script Name: EC_IT143_W4.2_MyFC_s1_co.sql
    Date: 2025-04-07
    Author: co
    Step 1: Ask a question
*/

-- Who are the top 3 highest paid players in the MyFC-1 dataset?
