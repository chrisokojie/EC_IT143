/*
    Ensign College � IT 143
    Script Name: EC_IT143_W4.2_MyFC-1_s4_co.sql
    Date: 2025-04-07
    Author: co
    Step 4: Turn query into a view
*/

CREATE VIEW vw_MyFC_Top3_HighestPaidPlayers AS
SELECT TOP 3 
    pl_id,
    mtd_salary
FROM [dbo].[tblPlayerFact]
ORDER BY mtd_salary DESC;
