/*
    Ensign College � IT 143
    Script Name: EC_IT143_W4.2_MyFC-1_s5.2_co.sql
    Date: 2025-04-07
    Author: co
    Step 5.2: Refine the table (No PRIMARY KEY)
*/

DROP TABLE IF EXISTS MyFC_Top3_HighestPaidPlayers;

CREATE TABLE MyFC_Top3_HighestPaidPlayers (
    pl_id INT NOT NULL,
    mtd_salary DECIMAL(18, 2) NOT NULL
    -- No PRIMARY KEY constraint to allow for potential duplicate IDs
);
