/*
    Ensign College � IT 143
    Script Name: EC_IT143_W4.2_MyFC-1_s8_co.sql
    Date: 2025-04-07
    Author: co
    Step 8: Call the stored procedure
*/

EXEC sp_Load_MyFC_Top3_HighestPaidPlayers;
