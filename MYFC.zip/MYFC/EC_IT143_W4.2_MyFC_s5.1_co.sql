/*
    Ensign College � IT 143
    Script Name: EC_IT143_W4.2_MyFC-1_s5.1_co.sql
    Date: 2025-04-07
    Author: co
    Step 5.1: Create a table from the view
*/

SELECT *
INTO MyFC_Top3_HighestPaidPlayers
FROM vw_MyFC_Top3_HighestPaidPlayers;
