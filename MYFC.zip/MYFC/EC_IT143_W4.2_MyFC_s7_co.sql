/*
    Ensign College � IT 143
    Script Name: EC_IT143_W4.2_MyFC-1_s7_co.sql
    Date: 2025-04-07
    Author: co
    Step 7: Create stored procedure
*/

CREATE OR ALTER PROCEDURE sp_Load_MyFC_Top3_HighestPaidPlayers
AS
BEGIN
    TRUNCATE TABLE MyFC_Top3_HighestPaidPlayers;

    INSERT INTO MyFC_Top3_HighestPaidPlayers
    SELECT *
    FROM vw_MyFC_Top3_HighestPaidPlayers;
END;
