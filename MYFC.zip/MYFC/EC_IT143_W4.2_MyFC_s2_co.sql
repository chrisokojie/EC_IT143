/*
    Ensign College � IT 143
    Script Name: EC_IT143_W4.2_MyFC-1_s2_co.sql
    Date: 2025-04-07
    Author: co
    Step 2: Begin creating an answer
*/

-- To answer this, I need to:
-- 1. Locate the table that contains player names and their salaries.
-- 2. Sort the data by salary in descending order.
-- 3. Select the top 3 entries.

-- My next step is to write an ad hoc query that retrieves the top 3 highest paid players.
