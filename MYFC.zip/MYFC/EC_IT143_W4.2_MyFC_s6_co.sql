/*
    Ensign College � IT 143
    Script Name: EC_IT143_W4.2_MyFC-1_s6_co.sql
    Date: 2025-04-07
    Author: co
    Step 6: Load table from the view (with column list)
*/

TRUNCATE TABLE MyFC_Top3_HighestPaidPlayers;

INSERT INTO MyFC_Top3_HighestPaidPlayers (pl_id, mtd_salary)
SELECT Pl_ID, mtd_Salary
FROM vw_MyFC_Top3_HighestPaidPlayers;
