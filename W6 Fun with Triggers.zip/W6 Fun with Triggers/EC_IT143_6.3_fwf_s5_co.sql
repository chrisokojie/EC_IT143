-- EC_IT143_6.3_fwf_s5_co.sql
-- Test the trigger with an update statement.

-- EC_IT143_6.3_fwf_s5_co.sql
-- Test the trigger with an update statement.

UPDATE [dbo].[t_w3_schools_customers]
SET ContactName = 'Jane Doe'
WHERE CustomerID = 1;  -- <-- Make sure this matches your actual key and an existing value

-- Verify that the trigger updated the audit fields
SELECT CustomerID, ContactName, last_modified_at, last_modified_by
FROM [dbo].[t_w3_schools_customers]
WHERE CustomerID = 1;

