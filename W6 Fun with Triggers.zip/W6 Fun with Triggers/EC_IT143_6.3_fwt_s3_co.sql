-- EC_IT143_6.3_fwt_s3_co.sql
-- Research reference: https://stackoverflow.com/questions/5677661/sql-server-trigger-to-update-last-modified-field

-- Goal: Create an AFTER UPDATE trigger that automatically populates these new columns with current date/time and user name.
-- Next step: Write the trigger and test it.
