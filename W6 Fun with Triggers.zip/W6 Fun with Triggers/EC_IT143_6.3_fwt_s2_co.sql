-- EC_IT143_6.3_fwt_s2_co.sql
-- Answer: Add two new columns to store the "last modified date" and "last modified by" info.
-- Next step: Alter the table to add these columns.

ALTER TABLE [dbo].[t_w3_schools_customers]
ADD last_modified_at DATETIME NULL,
    last_modified_by NVARCHAR(100) NULL;
