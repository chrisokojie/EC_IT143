-- EC_IT143_6.3_fwt_s4_co.sql
/*
    Script: EC_IT143_6.3_fwt_s4_co.sql
    Purpose: After update trigger to record the timestamp and username of the last modification.
    Author: Christopher Okojie
    Date: 2025-04-16
*/

-- EC_IT143_6.3_fwt_s4_co.sql (Corrected version)
/*
    Script: EC_IT143_6.3_fwt_s4_co.sql
    Purpose: After update trigger to record the timestamp and username of the last modification.
    Author: Christopher Okojie
    Date: 2025-04-16
*/

CREATE TRIGGER trg_update_customer_audit
ON [dbo].[t_w3_schools_customers]
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE c
    SET 
        last_modified_at = GETDATE(),
        last_modified_by = SUSER_SNAME()
    FROM [dbo].[t_w3_schools_customers] c
    INNER JOIN inserted i 
        ON c.CustomerID = i.CustomerID;  -- <-- Replace with actual PK column
END;

