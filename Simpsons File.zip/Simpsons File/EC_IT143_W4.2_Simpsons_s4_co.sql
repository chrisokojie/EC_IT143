-- ============================================================
-- Script Name: EC_IT143_W4.2_Simpsons-1_s4_co.sql
-- Author: Christopher Okojie
-- Purpose: Step 4 - Create a view for card member spending by main category
-- Date: 2025-04-07
-- ============================================================

-- Create a view to encapsulate the logic of card member spending by category
CREATE VIEW vw_CardMember_Spending AS
SELECT 
    Card_Member,
    LEFT(Category, CHARINDEX('-', Category + '-') - 1) AS main_category,
    COUNT(*) AS transaction_count,
    SUM(Amount) AS total_spent
FROM dbo.Planet_Express
WHERE Amount > 0
GROUP BY 
    Card_Member, 
    LEFT(Category, CHARINDEX('-', Category + '-') - 1);
