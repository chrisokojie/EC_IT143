-- ============================================================
-- Script Name: EC_IT143_W4.2_Simpsons-1_s1_co.sql
-- Author: Christopher Okojie
-- Purpose: Step 1 - Define a simple, focused question
-- Date: 2025-04-07
-- ============================================================

-- QUESTION:
-- What are the main spending categories of each card member based on their transactions in the Planet_Express dataset?
