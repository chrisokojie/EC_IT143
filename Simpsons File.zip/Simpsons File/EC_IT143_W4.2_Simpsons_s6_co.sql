-- ============================================================
-- Script Name: EC_IT143_W4.2_Simpsons-1_s6_co.sql
-- Author: Christopher Okojie
-- Purpose: Step 6 - Load data into the refined table from the view
-- Date: 2025-04-07
-- ============================================================

-- Truncate and insert for data reload
TRUNCATE TABLE CardMember_Spending;

INSERT INTO CardMember_Spending (Card_Member, main_category, transaction_count, total_spent)
SELECT 
    Card_Member, 
    LEFT(Category, CHARINDEX('-', Category + '-') - 1),
    COUNT(*),
    SUM(Amount)
FROM dbo.Planet_Express
WHERE Amount > 0
GROUP BY 
    Card_Member, 
    LEFT(Category, CHARINDEX('-', Category + '-') - 1);
