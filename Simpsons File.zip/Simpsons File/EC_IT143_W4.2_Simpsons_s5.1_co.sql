-- ============================================================
-- Script Name: EC_IT143_W4.2_Simpsons-1_s5.1_co.sql
-- Author: Christopher Okojie
-- Purpose: Step 5.1 - Create a table from the view
-- Date: 2025-04-07
-- ============================================================

-- Create a table from the view using SELECT INTO
SELECT *
INTO CardMember_Spending
FROM vw_CardMember_Spending;
