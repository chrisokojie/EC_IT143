-- ============================================================
-- Script Name: EC_IT143_W4.2_Simpsons-1_s2_co.sql
-- Author: Christopher Okojie
-- Purpose: Step 2 - Begin forming an answer to the question
-- Date: 2025-04-07
-- ============================================================

-- CURRENT THINKING:
-- To find the main spending categories, I need to parse the 'Category' field
-- and extract the portion before the dash (-) as the main category.
-- Then, for each card member, I will count transactions and sum amounts
-- for each main category.

-- NEXT STEPS:
-- Step 1: Write a query to extract main categories using LEFT and CHARINDEX.
-- Step 2: Group the results by card member and main category.
-- Step 3: Count transactions and sum amounts in each group.
