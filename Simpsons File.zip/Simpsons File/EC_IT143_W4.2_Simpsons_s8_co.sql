-- ============================================================
-- Script Name: EC_IT143_W4.2_Simpsons-1_s8_co.sql
-- Author: Christopher Okojie
-- Purpose: Step 8 - Execute the stored procedure
-- Date: 2025-04-07
-- ============================================================

-- Call the stored procedure to populate CardMember_Spending table
EXEC LoadCardMemberSpending;
