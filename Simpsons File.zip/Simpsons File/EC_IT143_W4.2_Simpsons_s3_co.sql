-- ============================================================
-- Script Name: EC_IT143_W4.2_Simpsons-1_s3_co.sql
-- Author: Christopher Okojie
-- Purpose: Step 3 - Ad hoc SQL query for extracting main categories
-- Date: 2025-04-07
-- ============================================================

SELECT 
    Card_Member,
    LEFT(Category, CHARINDEX('-', Category + '-') - 1) AS main_category,
    COUNT(*) AS transaction_count,
    SUM(Amount) AS total_spent
FROM dbo.Planet_Express
WHERE Amount > 0
GROUP BY 
    Card_Member, 
    LEFT(Category, CHARINDEX('-', Category + '-') - 1)
ORDER BY 
    Card_Member, 
    total_spent DESC;
