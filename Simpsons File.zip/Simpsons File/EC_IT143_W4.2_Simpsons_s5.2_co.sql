-- ============================================================
-- Script Name: EC_IT143_W4.2_Simpsons-1_s5.2_co.sql
-- Author: Christopher Okojie
-- Purpose: Step 5.2 - Refine table structure, add constraints and keys
-- Date: 2025-04-07
-- ============================================================

-- Drop and recreate the table to define constraints explicitly
DROP TABLE IF EXISTS CardMember_Spending;

CREATE TABLE CardMember_Spending (
    Card_Member NVARCHAR(50) NOT NULL,
    main_category NVARCHAR(100) NOT NULL,
    transaction_count INT NOT NULL,
    total_spent DECIMAL(18,2) NOT NULL,
    CONSTRAINT PK_CardMember_Spending PRIMARY KEY (Card_Member, main_category)
);
