--Q: What is the total number of records in a table?
--A: Let's ask SQL Server and find out...

Drop View IF Exists dbo.v_hello_world_load;
go

Create View dbo.v_hello_world_load
AS

/***********************************************************************************************
NAME:	dbo.v_hello_world_load;
PURPOSE: Create the Hello World - Load view

MODIFICATION LOG:
ver		Date		Author				Description 
---		---------=	------------------	--------------------------------------------------------
1.0		01/04/2025	Christopher Okojie	1. Build this script for EC_IT143_W4.2_hello_world_s3_co

RUNTIME:
1s

NOTES:
This script exists to help me learn steps 4 of 8 in the Answer Focused Approach for T-SQL Data manupulation
**********************************************************************************************************/
	Select 'Hello World' As my_message 
	 , COUNT(*) As total_of_records;

