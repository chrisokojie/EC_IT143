--Q: What is the total number of records in a table?
--A: Let's ask SQL Server and find out...

EXEC dbo.sp_load_hello_world;
GO