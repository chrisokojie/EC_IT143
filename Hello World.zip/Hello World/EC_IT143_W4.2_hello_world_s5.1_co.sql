--Q: What is the total number of records in a table?
--A: Let's ask SQL Server and find out...

select v.my_message
	 , v.total_of_records
	 into dbo.t_hello_world
	 from dbo.v_hello_world_load as v;
