--Q: What is the total number of records in a table?
--A: Let's ask SQL Server an find out...

-- 1 Reload Data
    INSERT INTO dbo.t_hello_world (my_message, total_of_records)
    SELECT 'Hello World' AS my_message, COUNT(*) AS total_of_records
    FROM dbo.t_hello_world; -- Ensure the count is from an actual table

    -- 2 Review the results
    SELECT * FROM dbo.t_hello_world;
