CREATE PROCEDURE dbo.sp_load_hello_world
AS
/***********************************************************************************************
NAME:	dbo.v_hello_world_load;
PURPOSE: Create the Hello World - Load view

MODIFICATION LOG:
ver		Date		Author				Description 
---		---------=	------------------	--------------------------------------------------------
1.0		01/04/2025	Christopher Okojie	1. Build this script for EC_IT143_W4.2_hello_world_s3_co

RUNTIME:
1s

NOTES:
This script exists to help me learn steps 4 of 8 in the Answer Focused Approach for T-SQL Data manupulation
**********************************************************************************************************/

BEGIN
    
-- 1 Reload Data
    INSERT INTO dbo.t_hello_world (my_message, total_of_records)
    SELECT 'Hello World' AS my_message, COUNT(*) AS total_of_records
    FROM dbo.t_hello_world; -- Ensure the count is from an actual table

    -- 2 Review the results
    SELECT * FROM dbo.t_hello_world;
END;
GO