DROP TABLE IF EXISTS dbo.t_my_community_1;
    CREATE TABLE dbo.t_my_community_1 (
        my_message NVARCHAR(50),
        total_revenue INT
    );
	go