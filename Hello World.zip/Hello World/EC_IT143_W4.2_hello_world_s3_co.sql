--Q: What is the total number of records in a table?
--A: Let's ask SQL Server an find out...

Select 'Hello World' As my_message 
	 , COUNT(*) As total_of_records;
