-- EC_IT143_6.3_fwf_s6b_co.sql
-- Step 6: Compare UDF results with ad hoc query

SELECT 
    ContactName,
    SUBSTRING(ContactName, CHARINDEX(' ', ContactName) + 1, LEN(ContactName)) AS LastName_AdHoc,
    dbo.ufn_GetLastName(ContactName) AS LastName_UDF
FROM dbo.t_w3_schools_customers
WHERE CHARINDEX(' ', ContactName) > 0;
