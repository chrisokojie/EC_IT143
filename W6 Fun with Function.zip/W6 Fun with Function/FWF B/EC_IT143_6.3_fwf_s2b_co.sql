-- EC_IT143_6.3_fwf_s2b_co.sql
-- Step 2: Begin creating an answer

-- I want to extract the last name from the [ContactName] column.
-- A good approach is to find the space and take the text after it.

-- Next step: Use CHARINDEX to locate the space and RIGHT or SUBSTRING to extract the last name.
