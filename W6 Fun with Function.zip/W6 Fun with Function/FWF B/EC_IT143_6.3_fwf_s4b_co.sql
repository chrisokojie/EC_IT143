-- EC_IT143_6.3_fwf_s4b_co.sql
-- Step 4: Research and test

-- Based on research from:
-- https://stackoverflow.com/questions/199933/how-do-i-extract-a-substring-in-sql-server
-- Tested with CHARINDEX and SUBSTRING to extract the portion after the space

SELECT 
    ContactName,
    SUBSTRING(ContactName, CHARINDEX(' ', ContactName) + 1, LEN(ContactName)) AS LastName
FROM dbo.t_w3_schools_customers
WHERE CHARINDEX(' ', ContactName) > 0;
