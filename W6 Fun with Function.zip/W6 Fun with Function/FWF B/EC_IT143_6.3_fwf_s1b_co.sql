-- EC_IT143_6.3_fwf_s1b_co.sql
-- Step 1: Ask the simplest form of the question

-- How do I extract the last name from the contact name?
