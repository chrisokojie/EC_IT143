-- EC_IT143_6.3_fwf_s8b_co.sql
-- Step 8: Ask the next question

-- What if a contact name has more than two words? How can I extract just the last word?
