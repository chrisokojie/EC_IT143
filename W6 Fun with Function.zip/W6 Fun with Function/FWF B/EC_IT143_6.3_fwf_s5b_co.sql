-- EC_IT143_6.3_fwf_s5b_co.sql
-- Step 5: User-defined scalar function

-- =============================================
-- Author: Christopher Okojie
-- Create date: 2025-04-16
-- Description: Returns the last name from a full contact name
-- =============================================

CREATE FUNCTION dbo.ufn_GetLastName (@ContactName NVARCHAR(100))
RETURNS NVARCHAR(50)
AS
BEGIN
    DECLARE @LastName NVARCHAR(50)

    IF CHARINDEX(' ', @ContactName) > 0
        SET @LastName = SUBSTRING(@ContactName, CHARINDEX(' ', @ContactName) + 1, LEN(@ContactName))
    ELSE
        SET @LastName = ''

    RETURN @LastName
END;
