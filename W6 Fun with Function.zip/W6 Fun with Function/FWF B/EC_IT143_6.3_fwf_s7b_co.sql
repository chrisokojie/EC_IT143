-- EC_IT143_6.3_fwf_s7b_co.sql
-- Step 7: 0 results expected test

WITH CTE_LastNameTest AS (
    SELECT 
        ContactName,
        SUBSTRING(ContactName, CHARINDEX(' ', ContactName) + 1, LEN(ContactName)) AS LastName_AdHoc,
        dbo.ufn_GetLastName(ContactName) AS LastName_UDF
    FROM dbo.t_w3_schools_customers
    WHERE CHARINDEX(' ', ContactName) > 0
)
SELECT * 
FROM CTE_LastNameTest
WHERE LastName_AdHoc <> LastName_UDF;
-- Expecting 0 results if the function is working correctly
