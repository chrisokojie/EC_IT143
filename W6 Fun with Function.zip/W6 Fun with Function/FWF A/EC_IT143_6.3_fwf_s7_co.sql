-- EC_IT143_6.3_fwf_s7_co.sql
-- Step 7: 0 results expected test

WITH CTE_FirstNameTest AS (
    SELECT 
        ContactName,
        SUBSTRING(ContactName, 1, CHARINDEX(' ', ContactName) - 1) AS FirstName_AdHoc,
        dbo.ufn_GetFirstName(ContactName) AS FirstName_UDF
    FROM dbo.t_w3_schools_customers
    WHERE CHARINDEX(' ', ContactName) > 0
)
SELECT * 
FROM CTE_FirstNameTest
WHERE FirstName_AdHoc <> FirstName_UDF;
-- Expecting 0 results if the function is working correctly
