-- EC_IT143_6.3_fwf_s5_co.sql
-- Step 5: User-defined scalar function

-- =============================================
-- Author: Christopher Okojie
-- Create date: 2025-04-16
-- Description: Returns the first name from a full contact name
-- =============================================

CREATE FUNCTION dbo.ufn_GetFirstName (@ContactName NVARCHAR(100))
RETURNS NVARCHAR(50)
AS
BEGIN
    DECLARE @FirstName NVARCHAR(50)

    IF CHARINDEX(' ', @ContactName) > 0
        SET @FirstName = SUBSTRING(@ContactName, 1, CHARINDEX(' ', @ContactName) - 1)
    ELSE
        SET @FirstName = @ContactName

    RETURN @FirstName
END;
