-- EC_IT143_6.3_fwf_s8_co.sql
-- Step 8: Ask the next question

-- How do I extract the last name from the contact name?
