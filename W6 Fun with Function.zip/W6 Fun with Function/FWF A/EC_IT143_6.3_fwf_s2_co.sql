-- EC_IT143_6.3_fwf_s2_co.sql
-- Step 2: Begin creating an answer

-- I want to extract the first name from the [ContactName] column.
-- A logical first step is to locate the space character and get the text before it.

-- Next step: Use CHARINDEX and SUBSTRING to extract the portion before the space.
