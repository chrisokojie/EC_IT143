-- EC_IT143_6.3_fwf_s4_co.sql
-- Step 4: Research and test

-- Based on research from:
-- https://stackoverflow.com/questions/7472832/sql-server-split-a-string
-- Tested the use of CHARINDEX and SUBSTRING for string manipulation

SELECT 
    ContactName,
    SUBSTRING(ContactName, 1, CHARINDEX(' ', ContactName) - 1) AS FirstName
FROM dbo.t_w3_schools_customers
WHERE CHARINDEX(' ', ContactName) > 0;
