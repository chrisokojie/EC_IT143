-- EC_IT143_6.3_fwf_s1_co.sql
-- Step 1: Ask the simplest form of the question

-- How do I extract the first name from the contact name?
